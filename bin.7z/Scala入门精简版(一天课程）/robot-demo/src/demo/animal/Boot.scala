package demo.animal

object Boot extends App {
  val a = Animal("cat")
  a.say()
  Cat().walk()
}

trait Animal {
  protected val name: String
  protected val age: Int
  def say():Unit = println(s"Hello, I'm $name. I'm $age years old")
  def walk():Unit
}

class Cat(myname: String, myage: Int) extends Animal {
  protected val name = myname
  protected val age = myage
  def this() = this("cat", 0)
  override def walk():Unit = println(s"$name is walking...")
}

object Animal {
  def apply(t: String) = t match {
    case "cat" => Cat()
    case _ => throw new Exception()
  }
}

object Cat {
  def apply() = new Cat()
}