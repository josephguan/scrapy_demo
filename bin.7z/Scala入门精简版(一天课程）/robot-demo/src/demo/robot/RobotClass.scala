package demo.robot

class Robot(var pos: Int) {
  def execute(cmd: Command): Unit = cmd.run(this)
}

trait Command {
  def run(robot: Robot): Unit
}

class Forward(steps: Int) extends Command {
  override def run(robot: Robot): Unit = robot.pos += steps
}

class Backward(steps: Int) extends Command {
  override def run(robot: Robot): Unit = robot.pos -= steps
}

class CommandList(cmds: List[Command]) extends Command {
  override def run(robot: Robot): Unit = cmds.foreach(c => c.run(robot))
}


object Boot extends App {
  val robot = new Robot(0)
  robot.execute(new Forward(10))
  println(robot.pos)
  robot.execute(new Backward(5))
  println(robot.pos)
  robot.execute(new CommandList(List(new Forward(10), new Backward(11))))
  println(robot.pos)
}

