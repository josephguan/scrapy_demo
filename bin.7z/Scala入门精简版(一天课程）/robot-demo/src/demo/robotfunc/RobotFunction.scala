package demo.robotfunc

case class Robot(pos: Int) {
  type Command = Robot => Robot

  def execute(commands: Command*): Robot = {
    commands.foldLeft(this)((robot, cmd) => cmd(robot))
  }
}

object Command {
  def forward(step: Int)(robot: Robot): Robot = Robot(robot.pos + step)

  def backward(step: Int)(robot: Robot): Robot = Robot(robot.pos - step)
}


object Boot extends App {
  println(Robot(0).execute(Command.forward(10)))
  println(Robot(0).execute(Command.backward(5)))
  println(Robot(0).execute(Command.forward(10), Command.backward(10)))
}