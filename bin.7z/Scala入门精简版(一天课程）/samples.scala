/**************************************************************
 初识Scala
 **************************************************************/
// hello world
println("Hello World!")

// even in [1, 20]
def printEven(): Unit = {
	var i = 1
	while(i <= 20) {
		if (i % 2 == 0) println(i)
		i = i + 1
	}
}

printEven()

// odd in [1, 20]
def printOdd() {
	for (i <- 1 to 20) {
		if (i % 2 != 0) println(i)
	}
}

printEven()


/**************************************************************
 函数式编程
 **************************************************************/

// vector
def vector(x: Int):List[List[Int]] = (1 to x).toList.map(List(_))

// P14 (*) Duplicate the elements of a list.
//     Example:
//     scala> duplicate(List('a, 'b, 'c, 'c, 'd))
//     res0: List[Symbol] = List('a, 'a, 'b, 'b, 'c, 'c, 'c, 'c, 'd, 'd)

object P14 {
  def duplicate[A](ls: List[A]): List[A] = ls flatMap { e => List(e, e) }
}


// msg count
val words = List("123 msg", "222 msg", "1 msg 3 msg")
def countMsg(str:String): Int = str.split(" ").count(x => x == "msg")
def countWords(w: List[String]): Int = w.map(countMsg).reduce(_ + _)

// P08 (**) Eliminate consecutive duplicates of list elements.
//     If a list contains repeated elements they should be replaced with a
//     single copy of the element.  The order of the elements should not be
//     changed.
//
//     Example:
//     scala> compress(List('a, 'a, 'a, 'a, 'b, 'c, 'c, 'a, 'a, 'd, 'e, 'e, 'e, 'e))
//     res0: List[Symbol] = List('a, 'b, 'c, 'a, 'd, 'e)

object P08 {
  // Standard recursive.
  def compressRecursive[A](ls: List[A]): List[A] = ls match {
    case Nil       => Nil
    case h :: tail => h :: compressRecursive(tail.dropWhile(_ == h))
  }

  // Tail recursive.
  def compressTailRecursive[A](ls: List[A]): List[A] = {
    def compressR(result: List[A], curList: List[A]): List[A] = curList match {
      case h :: tail => compressR(h :: result, tail.dropWhile(_ == h))
      case Nil       => result.reverse
    }
    compressR(Nil, ls)
  }

  // Functional.
  def compressFunctional[A](ls: List[A]): List[A] =
    ls.foldRight(List[A]()) { (h, r) =>
      if (r.isEmpty || r.head != h) h :: r
      else r
    }
}


// Stream
(1 to 1000000000).toStream.filter(_ % 2 == 0).take(5).foreach(println)

// 给定一个数，判断是否是斐波那契数列中的数
lazy val fib: Stream[BigInt] = 1 #:: 2 #:: (fib zip fib.tail map { case (x, y) => x + y })
def isFib(n: BigInt): Boolean = fib.dropWhile(_ < n).head == n


// 重构银行账户
def cashFlow(init: Int, deposits: Stream[Int]): Stream[Int] = {
	val balance = init + deposits.head
	balance #:: cashFlow(balance, deposits.tail)
}

/**************************************************************
 面向对象编程
 **************************************************************/

//---------- 类、成员、方法 -------------
class Cat{
	private val name = "cat"
	def say():Unit = println(s"Hello, I'm a $name")
}

//---------- 构造函数 -----------------
class Cat(val name: String, val age: Int) {
	def this() = this("cat", 0)
	def say():Unit = println(s"Hello, I'm $name. I'm $age years old")
}

//-------------- 继承、多态 ---------------------

abstract class Animal {
	protected val name: String
	protected val age: Int
	def say():Unit = println(s"Hello, I'm $name. I'm $age years old")
	def walk():Unit
}

class Cat(myname: String, myage: Int) extends Animal {
	protected val name = myname
	protected val age = myage
	def this() = this("cat", 0)
	override def walk():Unit = println(s"$name is walking...")
}

//-------------- trait 混入------------------------
// abstract class Animal 可改为 trait Animal
trait Singable {
	def sing(): Unit = println("la la la...")
}

//-------------- trait 依赖注入------------------------

trait Singable {
	self: Cat =>
	def sing(): Unit = println(s"la la la...I'm ${self.name}")
}

//-------------- 单例 ------------------------
object Singleton {
	var x: Int = 0
}

val x = Singleton
x.x=2
val y = Singleton
y.x
//-------------- 伴生对象/工厂类 ---------------------

trait Animal {
  protected val name: String
  protected val age: Int
  def say():Unit = println(s"Hello, I'm $name. I'm $age years old")
  def walk():Unit
}

class Cat(myname: String, myage: Int) extends Animal {
  protected val name = myname
  protected val age = myage
  def this() = this("cat", 0)
  override def walk():Unit = println(s"$name is walking...")
}

object Cat {
  def apply() = new Cat()
}

object Animal {
  def apply(t: String) = t match {
    case "cat" => Cat()
    case _ => throw new Exception()
  }
}

object Boot extends App {
  val a = Animal("cat")
  a.say()
  Cat().walk()
}