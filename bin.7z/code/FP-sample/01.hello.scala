// hello world
println("Hello World!")

// even in [1, 20]
def printEven(): Unit = {
	var i = 1
	while(i <= 20) {
		if (i % 2 == 0) println(i)
		i = i + 1
	}
}

printEven()

// odd in [1, 20]
def printOdd() {
	for (i <- 1 to 20) {
		if (i % 2 != 0) println(i)
	}
}

printEven()


// msg count
val file = List("warn 2013 msg", "warn 2013 msg", "warn 2013 msg")

// 阶乘。 递归。尾递归。
def factorial(n: BigInt): BigInt = {
	if (n == 1) 1
	else n * factorial(n-1)
}

def factorialPlus(n: BigInt): BigInt = {
	def factorialR(result: BigInt, x: BigInt): BigInt = {
		if (x == 1) result
		else factorialR(result * x, x-1)
	}
	factorialR(1, n)
}


// until
def until(p: =>Boolean)(f: =>Unit) {
	while(!p)(f)
}
