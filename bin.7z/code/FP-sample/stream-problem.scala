// P39 (*) A list of prime numbers.
//     Given a range of integers by its lower and upper limit, construct a list
//     of all prime numbers in that range.
//
//     scala> listPrimesinRange(7 to 31)
//     res0: List[Int] = List(7, 11, 13, 17, 19, 23, 29, 31)
def isPrime(num: Int): Boolean = {
	(num > 1) && (2 to Math.sqrt(num).toInt).forall(num % _ != 0)
}

val primes = Stream.cons(2, Stream.from(3, 2) filter { _.isPrime })

object S99Int {
  def listPrimesinRange(r: Range): List[Int] =
    primes dropWhile { _ < r.first } takeWhile { _ <= r.last } toList
}


// 给定一个数，判断是否是斐波那契数列中的数


lazy val fib: Stream[BigInt] 
  = 1 #:: 2 #:: (fib zip fib.tail map { case (x, y) => x + y })

def isFib(n: BigInt): Boolean = fib.dropWhile(_ < n).head == n




// stream 
def cashFlow(init: Int, deposits: Stream[Int]): Stream[Int] = {
	val balance = init + deposits.head
	balance #:: cashFlow(balance, deposits.tail)
}