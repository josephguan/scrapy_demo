function selectPic(name) {
    alert("you clicked pic: " + name);
};


$(document).ready(function() {
    $('.pic02').click(function() {
        selectPic($(this).attr('src'));
    });
});
