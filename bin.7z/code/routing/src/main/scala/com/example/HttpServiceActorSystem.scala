package com.example

import spray.routing.HttpService
import akka.actor.Actor
import spray.http.MediaTypes._


/**
 * Created by 10051039 on 2015/4/13.
 */
class HttpServiceActorSystem extends Actor with HttpService {

  def actorRefFactory = context

  def receive = runRoute(myRoute)

  val myRoute = path("helloworld") {
    get {
      respondWithMediaType(`text/html`) {
        complete {
          "Hello"
        }
      }
    }

  }


}
