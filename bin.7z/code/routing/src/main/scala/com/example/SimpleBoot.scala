package com.example

import spray.routing.SimpleRoutingApp
import akka.actor.ActorSystem

/**
 * Created by 10051039 on 2015/4/13.
 */
object SimpleBoot extends App with SimpleRoutingApp {

  implicit val system = ActorSystem("my-system")

  startServer(interface = "localhost", port = 3030) {
    path("hello") {
      get {
       complete {
         <h1>Hello World!</h1>
       }
      }
    }
  }

}
