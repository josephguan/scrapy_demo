package com.example

import akka.actor.Actor
import spray.routing._
import spray.httpx.Json4sSupport
import org.json4s.DefaultFormats


case class User(name: String, age: Int)

class MyServiceActor extends Actor with HttpService with Json4sSupport {

  val json4sFormats = DefaultFormats

  def actorRefFactory = context

  def receive = runRoute(myRoute)

  val myRoute =
    path("rest" / "user") {
      get {
        complete {
          User("Joe", 18)
        }
      }
    }
}

