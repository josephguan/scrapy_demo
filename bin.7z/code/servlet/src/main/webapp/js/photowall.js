function selectPic(name) {
	alert("You clicked: " + name);
}

$(document).ready(function(){
	$('.pic02').click(function(){
		selectPic("pic02");
	});

	$('.pic03').click(function(){
		$.ajax({
			url:"rest/user",
			type:"GET",
			success: function(data, status) {
				alert("name: " + data.name)
			}
		});
	});
});